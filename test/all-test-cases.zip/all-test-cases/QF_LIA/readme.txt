FISCHER10-10-fair.smt2
无输出,段错误