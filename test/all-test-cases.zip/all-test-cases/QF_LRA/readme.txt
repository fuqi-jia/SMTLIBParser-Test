Carpark2-t1-4.smt2
unknown 500s

Carpark2-ausgabe-8.smt2
unknown
240s

simple_example_1-node2318.smt2
unknown

p-DepotsNum_s8.msat.smt2

pd_not_sc_seen.base.smt2

pd_no_op_accs.induction.smt2

current_frame.base.smt2

good_frame_update.induction.smt2
FOMT_Solver: /pub/data/tansc/genOMT/solver/FOMT-Solver/SMTLIBParser/src/op_parser.cpp:504: std::shared_ptr<SMTLIBParser::DAGNode> SMTLIBParser::Parser::mkNot(std::shared_ptr<SMTLIBParser::DAGNode>): Assertion `param->getChildrenSize() == 1' failed.
Aborted (core dumped)