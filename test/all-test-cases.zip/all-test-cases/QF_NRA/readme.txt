exp-*-*.smt2
无输出，疑似段错误

MulliganEconomicsModel0055a.smt2
MulliganEconomicsModel0055e.smt2
unknown
分别为100s~200s左右

huge_runtime_PRAY.smt2
unknown 1000s

InVarSynth_agroce_minmax.c_Iteration2_1.smt2
unknown 600s

pentagon.t2.c_Iteration12_Loop_3-pieceTemplate.smt2
unknown 1100s